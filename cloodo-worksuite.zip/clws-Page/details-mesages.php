<div class="clws_iframe">
	<iframe src="<?php echo esc_url(CLWS_IFRAME_URL)?>apps/message" width="100%" height="100%" frameborder="0"></iframe>
</div>
