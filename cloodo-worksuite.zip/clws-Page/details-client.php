<div class="clws_iframe">
	<iframe id="iframechild" src="<?php echo esc_url(CLWS_IFRAME_URL)?>apps/clients/" width="100%" height="100%" frameborder="0"></iframe>
</div>




