=== Cloodo Work Suite ===
Contributors: cloodoteam
Donate link: https://cloodo.com/
Tags: cloodo, work suite, work, suite, cloodo worksuite, cloodo work suite
Requires at least: 4.7
Tested up to: 6.0
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage your leads, projects, tasks

== Description ==

Features:
* Manage customers and leads. Track client projects, invoices, proposals/estimates.
* Add your company’s employees, track their attendance and manage their leaves.
* Create contracts with clients with e-signatures.
* Create projects, add project members and track the project progress, expenses, earnings, timelogs, tasks, milestones.

== Frequently Asked Questions ==

= Is API required to run this plugin? =

Yes. Plugin will register an account automatic after you click register button on first screen on erp.cloodo.com. All your data will be saved here.

== Screenshots ==

1. Main screenshot

== Changelog ==

= 1.0 =
* Init

== Upgrade Notice ==

= 1.0 =
* First version